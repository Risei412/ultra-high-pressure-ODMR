# Kin On Ho published-spectrum reproduction bundle

This bundle contains the newly generated calculation files for reproducing
Ho et al. arXiv:2606.02399 Fig. 5(b) from the independently extracted
absorption spectra in Fig. 1(e).

## Main files

- `code/ho_spectrum_model.py`: published-spectrum interpolation model.
- `code/extract_ho_fig1e.py`: reproducible vector-PDF extraction.
- `code/data/ho_fig1e_absorption.csv`: extracted spectra at 0--120 GPa.
- `code/repro_yield.py`: Ho-theory and experimental reproduction gates.
- `code/tests/test_ho_spectrum_model.py`: cross-figure reproduction tests.
- `code/tests/test_repro_yield.py`: observable-separation tests.
- `docs/sanity_check_pl_yield.md`: scope, metrics, and interpretation.
- `kin_on_ho_published_reproduction.patch`: alternative one-command patch.

## Validation result

- Fig. 5(b) theory residual: 1.5% at 532 nm, 0.4% at 457 nm.
- Theory dome peaks: 17/17 GPa and 88/88 GPa.
- Experimental PL residual: 10.0% and 10.2%.
- Reconstructed optimum at 120 GPa: 440.7 nm.
- 457 nm sensitivity penalty relative to optimum: x1.045.
- Targeted tests: 31 passed.

## Run

```bash
cd code
python repro_yield.py
python -m pytest tests/test_repro_yield.py tests/test_ho_spectrum_model.py -q
```

This reproduces the published curves. It is not an independent DFT or
dynamical-Jahn--Teller calculation because the mode-resolved microscopic
inputs are not present in the arXiv source archive.
