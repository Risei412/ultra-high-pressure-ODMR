"""Create an audit figure explaining the Ho Fig. 5(b) reproduction PASS."""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from ho_spectrum_model import HoPublishedSpectrumModel
from repro_yield import (EXPT_MAX_FRACTIONAL_RMS, EXPT_MAX_PEAK_ERROR_GPA,
                         HO_MAX_FRACTIONAL_RMS, HO_MAX_PEAK_ERROR_GPA,
                         compare_experiment, compare_ho_theory, load,
                         predict_absorption)


HERE = Path(__file__).resolve().parent
# Repository layout: audit/code/script.py.  Standalone bundle layout:
# bundle/script.py.  Support both without requiring the caller's cwd.
ROOT = HERE.parent if HERE.name == 'code' else HERE
OUT_PNG = ROOT / 'docs' / 'ho_fig5b_reproduction_pass.png'
OUT_PDF = ROOT / 'docs' / 'ho_fig5b_reproduction_pass.pdf'


def scaled_prediction(model, wavelength, pressure, reference):
    prediction = predict_absorption(model, wavelength, pressure)
    scale = np.sum(prediction * reference) / np.sum(prediction * prediction)
    return scale * prediction


def main():
    model = HoPublishedSpectrumModel()
    data = load()
    theory = compare_ho_theory(model, data)
    experiment = compare_experiment(model, data, collection=False)

    plt.rcParams.update({
        'font.size': 10,
        'axes.titlesize': 11,
        'axes.labelsize': 10,
        'legend.fontsize': 8.5,
        'figure.dpi': 160,
    })
    fig = plt.figure(figsize=(11.2, 7.7))
    fig.subplots_adjust(left=0.075, right=0.985, bottom=0.12, top=0.88,
                        hspace=0.48, wspace=0.22)
    grid = fig.add_gridspec(2, 2, height_ratios=(1.25, 1.0))

    colors = {532: '#238b45', 457: '#2166ac'}
    for column, wavelength in enumerate((532, 457)):
        ax = fig.add_subplot(grid[0, column])
        pressure, reference = data[f'theory{wavelength}_ho']
        measured_pressure = data[f'expt{wavelength}'][0]
        mask = ((pressure >= measured_pressure.min())
                & (pressure <= measured_pressure.max()))
        pressure, reference = pressure[mask], reference[mask]
        reconstruction = scaled_prediction(
            model, wavelength, pressure, reference)
        ax.plot(pressure, reference, color='0.15', lw=2.2,
                label='Ho Fig. 5(b), calculated')
        ax.plot(pressure, reconstruction, color=colors[wavelength], lw=2.0,
                ls='--', label='Reconstructed from Ho Fig. 1(e)')
        metrics = theory[str(wavelength)]
        ax.axvline(metrics['peak_reference_GPa'], color='0.15', alpha=0.25,
                   lw=1)
        ax.set_title(
            f'{wavelength} nm: RMS {metrics["fractional_rms"]*100:.1f}%, '
            f'peak {metrics["peak_model_GPa"]:.0f}/'
            f'{metrics["peak_reference_GPa"]:.0f} GPa')
        ax.set_xlabel('Pressure (GPa)')
        ax.set_ylabel('Absorption (independently scaled a.u.)')
        ax.set_ylim(bottom=0)
        ax.grid(alpha=0.22)
        ax.legend(frameon=False, loc='best')

    ax_rms = fig.add_subplot(grid[1, 0])
    labels = ['Ho 532', 'Ho 457', 'Expt 532', 'Expt 457']
    rms = [theory['532']['fractional_rms'] * 100,
           theory['457']['fractional_rms'] * 100,
           experiment['532']['fractional_rms'] * 100,
           experiment['457']['fractional_rms'] * 100]
    thresholds = [HO_MAX_FRACTIONAL_RMS * 100] * 2 + [
        EXPT_MAX_FRACTIONAL_RMS * 100] * 2
    x = np.arange(len(labels))
    bars = ax_rms.bar(x, rms, color=['#238b45', '#2166ac', '#74c476', '#6baed6'])
    ax_rms.scatter(x, thresholds, marker='_', s=900, linewidths=3,
                   color='#b2182b', label='PASS ceiling')
    for bar, value in zip(bars, rms):
        ax_rms.text(bar.get_x() + bar.get_width()/2, value + 0.45,
                    f'{value:.1f}%', ha='center', va='bottom', fontsize=9)
    ax_rms.set_xticks(x, labels)
    ax_rms.set_ylabel('Fractional RMS error (%)')
    ax_rms.set_title('Shape gate: every bar is below its ceiling')
    ax_rms.set_ylim(0, 19)
    ax_rms.grid(axis='y', alpha=0.22)
    ax_rms.legend(frameon=False, loc='upper left')

    ax_peak = fig.add_subplot(grid[1, 1])
    peak_errors = [theory['532']['peak_error_GPa'],
                   theory['457']['peak_error_GPa'],
                   experiment['532']['peak_error_GPa'],
                   experiment['457']['peak_error_GPa']]
    peak_thresholds = [HO_MAX_PEAK_ERROR_GPA] * 2 + [
        EXPT_MAX_PEAK_ERROR_GPA] * 2
    bars = ax_peak.bar(
        x, peak_errors, color=['#238b45', '#2166ac', '#74c476', '#6baed6'])
    ax_peak.scatter(x, peak_thresholds, marker='_', s=900, linewidths=3,
                    color='#b2182b', label='PASS ceiling')
    for bar, value in zip(bars, peak_errors):
        ax_peak.text(bar.get_x() + bar.get_width()/2, value + 0.25,
                     f'{value:.0f}', ha='center', va='bottom', fontsize=9)
    ax_peak.set_xticks(x, labels)
    ax_peak.set_ylabel('Peak-pressure error (GPa)')
    ax_peak.set_title('Peak gate: every bar is below its ceiling')
    ax_peak.set_ylim(0, 12)
    ax_peak.grid(axis='y', alpha=0.22)
    ax_peak.legend(frameon=False, loc='upper left')

    fig.suptitle(
        'Why the Ho et al. Fig. 5(b) reproduction passes',
        fontsize=15, fontweight='bold')
    fig.text(
        0.5, 0.025,
        'PASS requires both wavelengths to satisfy both shape and peak gates. '
        'Experimental PL is a separate shape check and is independently scaled.',
        ha='center', fontsize=9)
    fig.savefig(OUT_PNG, bbox_inches='tight')
    fig.savefig(OUT_PDF, bbox_inches='tight')
    print(OUT_PNG)
    print(OUT_PDF)


if __name__ == '__main__':
    main()
