# Ho et al. Fig. 5(b) reproduction code

This bundle reproduces the audit graph and numerical PASS decision discussed
for Ho et al. (2026), Fig. 5(b).

## Environment

Python 3.10 or newer is recommended.

```bash
python -m pip install numpy scipy matplotlib pytest
```

## Generate the graph

Run from this directory:

```bash
python plot_fig5b_reproduction_pass.py
```

Outputs are written to `docs/ho_fig5b_reproduction_pass.png` and `.pdf`.

## Reproduce the numerical audit

```bash
python repro_yield.py
python -m pytest tests/test_repro_yield.py tests/test_ho_spectrum_model.py -q
```

The published-curve model reconstructs Ho Fig. 1(e), then tests it against the
independently digitised Fig. 5(b) curves. It is a cross-figure reproduction,
not an independent DFT/dynamical-Jahn--Teller calculation.

PASS limits:

- Ho calculated absorption: fractional RMS <= 10% per wavelength and peak
  error <= 5 GPa.
- Experimental PL shape: fractional RMS <= 16% per wavelength and peak error
  <= 10 GPa.
