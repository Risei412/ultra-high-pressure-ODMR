# Ho-integrated ODMR next-step package

This update adds the first frozen sensitivity layer after successful
cross-figure reproduction of Ho et al.'s published absorption spectra.

New files:

- `theory_freeze_v3_ho_integrated.md`: scientific scope, 120 GPa result,
  experimental gates, novelty assessment, and falsification rules.
- `code/ho_odmr_sensitivity.py`: external Ho optical kernel → detected rate →
  conditional ODMR sensitivity.
- `code/report_120gpa_sensitivity.py`: reproducible wavelength table.
- `code/tests/test_ho_odmr_sensitivity.py`: frozen numerical and assumption
  checks.
- `code/data/ho_120gpa_wavelength_scan.csv`: generated optical-limit table.

The important boundary is explicit: 440.65 nm and the ×1.04494 penalty at
457 nm are optical-limit results. The actual ODMR sensitivity gain requires
measured wavelength-dependent rate, contrast, and linewidth.
